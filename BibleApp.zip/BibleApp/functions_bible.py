import requests
import sys

"""    def check_for_multiple_books():
        name = user_input()
        kings = "kings"
        chronicles = "chronicles"
        thessalonians = 'thessalonians'
        timothy = "timothy"
        peter = "peter"
        john = "john"
        names_with_multiple_books = {kings: 2, chronicles: 2, thessalonians: 2, timothy: 2, peter: 2, john: 3}
        if name.upper() in names_with_multiple_books.keys() or name.lower() in names_with_multiple_books or name in \
                names_with_multiple_books:
            print("This name has more than one book")
            book_number_multiple = int(input("Enter the book number:"))
            chapter_multiple_book = int(input("Enter the chapter:"))
            verse_multiple_book = int(input("Enter the verse:"))
            req = str(
                'https://labs.bible.org/api/?passage=%d%20%d:%d&type=text&formatting=plain'.format(book_number_multiple,
                                                                                                   name,
                                                                                                   chapter_multiple_book,
                                                                                                   verse_multiple_book))  # there are more than one book for several of the named books in the bible
            # as such it is noteworthy to enter a specific book number
            # print('?passage = %d%s20%d:%d'%(bookNumber,name,chapter,verse))    Format tactic to get the input
            # accepted
            res = "https://labs.bible.org/api/?passage={0}{1}%20{2}:{3}&type=text&formatting=plain".format(
                book_number_multiple,
                name,
                chapter_multiple_book,
                verse_multiple_book)  # set the request and response into a formatted string
        else:
            chapter_single_book = int(input("Enter the chapter:"))
            verse_single_book = int(input("Enter the verse:"))
            req = str(
                'https://labs.bible.org/api/?passage=%s%20%d:%d&type=text&formatting=plain'.format(
                    name,
                    chapter,
                    verse))  # there are more than one book for several of the named books in the bible
            # as such it is noteworthy to enter a specific book number
            # print('?passage = %d%s20%d:%d'%(bookNumber,name,chapter,verse))    Format tactic to get the input
            # accepted
            res = "https://labs.bible.org/api/?passage={0}%20{1}:{2}&type=text&formatting=plain".format(
                name,
                chapter,
                verse)  # set the request and response into a formatted string
        response = requests.get(res)
        return response.text
"""


def specific ():
    # This function returns a variable from the function right below and returns whatever outputs that function returns
    specify_verse = check_for_multiple_books()
    return specify_verse


def check_for_multiple_books ():
    # this is a in depth explanation for the function right below this line
    """
        This function checks to see if a certain name returned from the user_input function is in the dictionary of
    names with more than one book belonging to them. If the book is in the dictionary, then the function prints tells
    the user that the book has more than one name and then asks for the exact book number since there could be as
    many as 3 different books for example the book of John ect. Also with testing the name in the dictionary,
    the name is tested both uppercase as as well as lowercase to see if it is in of the of the keys of the
    dictionary. Moving further, the function will use one formatted string name req which is abbreviated for the word
    request: this for the actual request converted to the appropriate string with indexes for the different values
    within the request. In middle of the string lies the numbers 20 and follows with a text formatting %. This by
    default is required as including the string without the 20 before the integer following it, returns more than
    just the entered verse query but all of the verses and that verse combined for that whole chapter that contains
    that verse. Finally the response variable is set to the name" 'response' and this is used with the request get
    function to return the text response from the string. The return value ultimately is the response.text variable.
        It is important to mention that since not all names have multiple books. So the names not included in the
    dictionary are placed in a separate block that just prompts the user for the chapter number and verse number.Try \
     except blocks are used for both conditions of multiple books to names as well as single book names that. The try
     except statements test for either incorrect values entered or connection errors with sent requests"""

    def user_input ():
        """Simply returns the name string for a book in the bible"""
        input_name = input("Enter the name of the book:")
        return input_name

    # string vars used to test string names to the input name string in the returned input value above
    name = user_input()
    kings = "kings"
    chronicles = "chronicles"
    thessalonians = 'thessalonians'
    timothy = "timothy"
    peter = "peter"
    john = "john"
    samuel = "samuel"
    # dictionary used to group just the book names and their belonging books, these names have more than one book
    # if so the block includes the book number int var
    names_with_multiple_books = {kings: 2, chronicles: 2, thessalonians: 2, timothy: 2, peter: 2, john: 3,samuel:2}
    if name.upper() in names_with_multiple_books.keys() or name.lower() in names_with_multiple_books or name in \
            names_with_multiple_books:

        sys.stdout.write("This name has more than one book")
        print()
        try:  # tests for and catches exceptions with incorrect values or connection errors with outgoing requests
            book_number_multiple = int(input("Enter the book number:"))
            chapter_multiple_book = int(input("Enter the chapter:"))
            verse_multiple_book = int(input("Enter the verse:"))
        except ValueError:
            sys.stdout.write("book numbers, chapters, and verses are all integers")
        except ConnectionError:
            sys.stdout.write("request was unsuccessful")

        else:  # if no exception is thrown, the input is used

            # as such it is noteworthy to enter a specific book number
            # print('?passage = %d%s20%d:%d'%(bookNumber,name,chapter,verse))    Format tactic to get the input
            # accepted
            # requests variable is formatted to match requests on the api's website requests
            # the difference only is the specific details of the verse are indexes in the string and formatted
            # to match the user's input zzz
            req = "https://labs.bible.org/api/?passage={0}{1}%20{2}:{3}&type=text&formatting=plain".format(
                book_number_multiple,
                name,
                chapter_multiple_book,
                verse_multiple_book)  # set the request and response into a formatted string
            response = requests.get(req)
            return response.text  # return value
    else:
        try:  # tests and catches exceptions with incorrect values or connection errors with outgoing requests
            chapter_single_book = int(input("Enter the chapter:"))
            verse_single_book = int(input("Enter the verse:"))
        except ValueError:
            sys.stdout.write("book numbers, chapters, and verses are all integers")
        except ConnectionError:
            sys.stdout.write("request was unsuccessful")
        else:
            # as such it is noteworthy to enter a specific book number
            # print('?passage = %d%s20%d:%d'%(bookNumber,name,chapter,verse))    Format tactic to get the input
            # accepted
            res = "https://labs.bible.org/api/?passage={0}%20{1}:{2}&type=text&formatting=plain".format(
                name,
                chapter_single_book,
                verse_single_book)  # set the request and response into a formatted string
            response = requests.get(res)  # response variable uses request.get function to obtain the request result
            return str("%s\n" % response.text)  # return value formatted with new line char to provide extra spacing


def random_verse ():
    """This structure and
      return value and request try/except similar except. It uses a preformatted string from the
    website that is set to a formatted string called request_random The actual characters in the formatted string
    are just the word random with the type being plain for plain text and text being for text strings instead of json
    xml ect."""
    try:
        request_random = requests.get('https://labs.bible.org/api/?passage=random&type=text&formatting=plain')
    except ConnectionError:
        sys.stdout.write("request was unsuccessful")
    else:
        return str("%s\n" % request_random.text)  # return value formatted with new line char to provide extra spacing


def verse_of_the_day ():
    """The function structure and
     return value and request try/except similar except. It uses a preformatted string from the
        website that is set to a formatted string called request_vod. The actual characters in the formatted string
        are just the word random with the type being plain for plain text and
        text being for text strings instead of json
        xml ect."""
    try:
        request_vod = requests.get('https://labs.bible.org/api/?passage=votd&type=text&formatting=plain')
    except ConnectionError:
        sys.stdout.write("request was unsuccessful")
    else:
        return str("%s\n" % request_vod.text)  # return value formatted with new line char to provide extra spacing
