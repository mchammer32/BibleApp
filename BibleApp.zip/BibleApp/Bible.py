import functions_bible
import sys
# The functions and their explanations are found in the script functions_bible.py These functions were imported. This
# program will use a api to request specific, random, or verses of the day. The verses will be retrieved via
# functions that call the request from the website's api and return a plaintext answer.


"""The if/elif statements are to choose which action the script will designate program output inside a while loop. If
 the user enters one of the three words categories: random (R/r/random/RANDOM/Random), specific(S/s/specific/SPECIFIC)
, or verse of the day (VOD/vod/verseoftheday/VERSEOFTHEDAY/verse of the day/ VERSE OF THE DAY/ Verse of the day)/
  then the request will return just that unless the input is invalid.
Additionally, the user has the option of exiting by using 'exit' to terminate the program. """


# The main function will start the script and will contain a while loop that checks input, returns the corresponding \
# query

def main():
    while True:
        try:  # contains the input inside a try except statement in case illegal arguments or argument amounts \
            # are entered
            request_selection_use = input("Enter S for specific, R for random, VOD for verse of the day or "
                                          "exit "
                                          "to "
                                          "leave the program:")
        except ValueError:  # catches illegal inputs ex: string when an input needs an int ect.
            sys.stdout.write("Value must be a string for names and integers for book numbers, chapters, and verses")
        except ConnectionError:  # catches exception raised if the request is not accepted and the connection canceled
            sys.stdout.write("Connection was rejected")
        except IndexError:  # catches exceptions due to errors in the index such as illegal index args and illegal \
            # arg amounts
            sys.stdout.write("Invalid argument types or argument length")
        else:  # if no exception is thrown then the input is used in the if conditionals below

            # for the conditions, strings are set to accept both lower, upper, and partial upper case string inputs
            # additionally, if the input is not the full word and merely the first letter either upper or lowercase \
            # the input is still accepted
            if request_selection_use == "specific".islower() or request_selection_use == "specific".upper() or \
                    request_selection_use == \
                    "Specific" \
                    or request_selection_use == "s".lower() or request_selection_use == "S".upper():
                print()
                sys.stdout.write(functions_bible.specific())

            elif request_selection_use == "random".lower() or request_selection_use == "random".upper() or request_selection_use \
                    == "Random" \
                    or request_selection_use == "r".lower() or request_selection_use == "r".upper():
                print()
                sys.stdout.write(functions_bible.random_verse())
                print()
            elif request_selection_use == "votd".lower() or request_selection_use == "votd".upper() or request_selection_use \
                    == "verse of the day".lower() or request_selection_use \
                    == "verse of the day".upper() \
                    or request_selection_use == "vod".lower() or request_selection_use == "vod".upper() or request_selection_use == \
                    "verseoftheday".upper() or request_selection_use \
                    == "verseoftheday".lower() or request_selection_use == "Verse of the day" or request_selection_use \
                    == "Verse of the Day":
                print()
                sys.stdout.write(functions_bible.verse_of_the_day())
            # the last elif tests for the input of the sentinel value of 'exit' and terminates the program when
            # if the value is entered, the program terminates and prints goodbye to the user receiving it with the  \
            # exit code 0
            elif request_selection_use == "exit".upper() or request_selection_use == "exit".lower():
                sys.stdout.write("Goodbye!!!")
                exit(0)
            else:  # to finish off the multiline if statement block, else is used to continue the loop so that the
                # faulty input is ignored and unless 'exit', the loop continues
                continue
        finally:  # the finally block is used to indicate the end of the program no regardless of the sentinel \
            # value being entered or if a request is made
            print()
            sys.stdout.write("Program finished")

            # this conditional tests for name equaling main and if so , starts the beginning of the program
if __name__ == "__main__":
    print(main())
main()